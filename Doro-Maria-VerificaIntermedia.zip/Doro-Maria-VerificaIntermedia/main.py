from funzioniMenu import menu


def main():
    #lista creata per avere una base nel test, commentabile
    lista = []

    menu(lista)


main()
